package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class cse_update extends JFrame implements ActionListener {
    JTextField enterNa,enterBa,enterRo,enterPo;

    JButton cse_20,cse_21,cse_22,cse_17,cse_18,cse_19,back;
    cse_update(){
        getContentPane().setBackground(new Color(168,203,255));

        JLabel lemail = new JLabel(" UPDATE INFORMATION ");
        lemail.setBounds(100, 30, 850, 30);
        lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,30));
        this.add(lemail);

        JLabel enterName = new JLabel(" Name");
        enterName.setBounds(400, 130, 130, 30);
        enterName.setFont(new Font(enterName.getFont().getName(), Font.BOLD,15));
        enterName.setVisible(true);
        this.add(enterName);

        this.enterNa = new JTextField();
        this.enterNa.setBounds(600, 130, 200, 30);
        this.enterNa.setVisible(true);
        this.add(this.enterNa);

        JLabel batch = new JLabel("Batch");
        batch.setBounds(400, 180, 180, 30);
        batch.setFont(new Font(batch.getFont().getName(),Font.BOLD,15));
        batch.setVisible(true);
        this.add(batch);

        this.enterBa = new JTextField();
        this.enterBa.setBounds(600, 180, 200, 30);
        this.enterBa.setVisible(true);
        this.add(this.enterBa);


        JLabel roll = new JLabel("Roll");
        roll.setBounds(400, 230, 130, 30);
        roll.setFont(new Font(roll.getFont().getName(),Font.BOLD,15));
        roll.setVisible(true);
        this.add(roll);

        this.enterRo = new JTextField();
        this.enterRo.setBounds(600, 230, 200, 30);
        this.enterRo.setVisible(true);
        this.add(this.enterRo);



        JLabel poaition = new JLabel("Position");
        poaition.setBounds(400, 280, 130, 30);
        poaition.setFont(new Font(poaition.getFont().getName(),Font.BOLD,15));
        poaition.setVisible(true);
        this.add(poaition);

        this.enterPo = new JTextField();
        this.enterPo.setBounds(600, 280, 200, 30);
        this.enterPo.setVisible(true);
        this.add(this.enterPo);


        cse_20 = new JButton("CSE 20");
        cse_20.setBackground(Color.BLUE);
        cse_20.setForeground(Color.BLACK);
        cse_20.setBounds(400, 350, 100, 20);
        cse_20.addActionListener(this);
        add(this.cse_20);

      /*  cse_21 = new JButton("CSE 21");
        cse_21.setBackground(Color.BLUE);
        cse_21.setForeground(Color.BLACK);
        cse_21.setBounds(530, 350, 100, 20);
        cse_21.addActionListener(this);
        add(this.cse_21);

        cse_22 = new JButton("CSE 22");
        cse_22.setBackground(Color.BLUE);
        cse_22.setForeground(Color.BLACK);
        cse_22.setBounds(630, 350, 100, 20);
        cse_22.addActionListener(this);
        add(this.cse_22);

        cse_17 = new JButton("CSE 17");
        cse_17.setBackground(Color.BLUE);
        cse_17.setForeground(Color.BLACK);
        cse_17.setBounds(400, 400, 100, 20);
        cse_17.addActionListener(this);
        add(this.cse_17);

        cse_18 = new JButton("CSE 18");
        cse_18.setBackground(Color.BLUE);
        cse_18.setForeground(Color.BLACK);
        cse_18.setBounds(530, 400, 100, 20);
        cse_18.addActionListener(this);
        add(this. cse_18);*/

        cse_19 = new JButton("CSE 19");
        cse_19.setBackground(Color.BLUE);
        cse_19.setForeground(Color.BLACK);
        cse_19.setBounds(630, 350, 100, 20);
        cse_19.addActionListener(this);
        add(this.cse_19);

        back = new JButton("Back");
        back .setBackground(Color.BLUE);
        back .setForeground(Color.BLACK);
        back .setBounds(500, 400, 150, 20);
        back .addActionListener(this);
        add(this. back );





        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/updateing.png"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(70,00,200,450);
        add(profileLable);





        setSize(900, 600);
        setLocation(250, 20);
        setLayout(null);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==cse_20){
           String name= enterNa.getText();
           String roll= enterRo.getText();
           String batch= enterBa.getText();
           String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_20(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);
              //  new Login();

                new cse_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()==cse_21) {
            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_21(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);
              //  new Login();
                new cse_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()==cse_22) {
            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_22(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);
               // new CSE();
                new cse_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()==cse_18) {
            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_18(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);
              // new cse();

                new cse_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }

        } else if (e.getSource()==cse_19) {
            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_19(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);
               // new cse();

                new cse_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()==cse_17) {

            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into billsystem.cse_table_17(name,roll,batch,position) values('"+name+"','"+roll+"','"+batch+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                // back.setVisible(false);

                new cse_admin();
              // new cse();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()==back) {
            setVisible(false);
            new cse_admin();

        }
    }

    public static void main(String[] args) {
        new cse_update();
    }
}

