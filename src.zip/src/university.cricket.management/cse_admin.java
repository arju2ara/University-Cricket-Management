package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class cse_admin extends JFrame implements ActionListener {

    JButton update,show,back,delete;
    cse_admin(){

        getContentPane().setBackground(new Color(54, 141, 129));

        update = new JButton("Update");
        update.setBackground(Color.BLUE);
        update.setForeground(Color.BLACK);
       update.setBounds(70, 150, 150, 30);
        update.addActionListener(this);
        add(this. update);


        delete = new JButton("Delete");
        delete.setBackground(Color.BLUE);
        delete.setForeground(Color.BLACK);
        delete.setBounds(70, 200, 150, 30);
        delete.addActionListener(this);
        add(this.delete);


       show = new JButton("Show details");
       show.setBackground(Color.BLUE);
        show.setForeground(Color.BLACK);
       show.setBounds(70, 250, 150, 30);
       show.addActionListener(this);
        add(this. show);


        back = new JButton("back");
       back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(70, 300, 150, 30);
        back.addActionListener(this);
        add(this.back);



        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/details.png"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(100,0,600,500);
        add(profileLable);


        setSize(800, 600);
        setLocation(350, 200);
        setLayout(null);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==update){
            setVisible(false);

            new cse_update();

        } else if (e.getSource()==show) {
            setVisible(false);
            new cse_show_details();


        } else if (e.getSource()== back) {
            setVisible(false);
            new teams();

        }

        else if (e.getSource()== delete) {
            setVisible(false);
            new cse_delete();

        }


    }

    public static void main(String[] args) {
        new cse_admin();
    }
}
