package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class member_me_table_19 extends JFrame {

    private JFrame frame;
    private JTextArea tableInfoTextArea;
    private JButton showTableButton,cse_22;


    public member_me_table_19() {
        frame = new JFrame("Players Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800); // Set the size to 1000x800
        frame.setLocation(250, 0);
        frame.setLayout(new BorderLayout());

        cse_22 = new JButton("EEE 22");
        cse_22.setBackground(Color.BLUE);
        cse_22.setForeground(Color.BLACK);
        cse_22.setBounds(630, 350, 100, 20);
        // cse_22.addActionListener(this);
        add(this.cse_22);

        // JTextArea to display table information
        tableInfoTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(tableInfoTextArea);

        // Button to show table data
        showTableButton = new JButton("Show Table Data");
        showTableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // if(e.getSource()== cse_20)

                showTableInformation();
            }
        });

        // Back button
        JButton backButton = new JButton("Back ");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the Players page
                new me_show_details_member(); // Open the Dashboard page
            }
        });

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(showTableButton);
        buttonPanel.add(backButton);

        // Add components to the frame
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private void showTableInformation() {
        try {

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Billsystem", "root", "root");


            Statement statement = connection.createStatement();


            ResultSet resultSet = statement.executeQuery("SELECT * FROM me_table_19");


            tableInfoTextArea.setText("");
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) {

                    String columnName = metaData.getColumnName(i);
                    String value = resultSet.getString(i);
                    tableInfoTextArea.append( columnName +":"+value + "\n");
                }
                tableInfoTextArea.append("\n");
            }

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error fetching table information: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new member_me_table_19();
        });
    }
}


/*
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class member_me_table_19 extends JFrame {
    private JTable table;
    private JScrollPane scrollPane;

    public member_me_table_19() {

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        createUI();
    }

    public void createUI() {
        table = new JTable();
        table.setBackground(Color.cyan);

        Font tableFont = new Font("Arial", Font.ITALIC, 16);
        table.setFont(tableFont);
        int rowHeight = 60;
        table.setRowHeight(rowHeight);
        table.setRowHeight(rowHeight);
        Font headerFont = new Font("Arial", Font.BOLD, 18);
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(headerFont);
        scrollPane = new JScrollPane(table);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://root@localhost:3306/Billsystem","root","root");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM billsystem.me_table_19");

            table.setModel(buildTableModel(resultSet));

            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // add(scrollPane);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(e.getSource()==backButton){
                    setVisible(false);
                    new me_member().setVisible(true);

                }
                // Add code here to navigate back to the cse_admin page.
                // Example: new cse_admin().setVisible(true);
            }
        });

        // Assuming you are using BorderLayout, add the components.
        add(scrollPane, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }
    public static TableModel buildTableModel(ResultSet resultSet) throws Exception {
        java.sql.ResultSetMetaData metaData = resultSet.getMetaData();

        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int column = 1; column <= columnCount; column++) {
            columnNames[column - 1] = metaData.getColumnName(column);
        }

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new member_me_table_19().setVisible(true);
        });
    }
}
*/