package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class teams extends JFrame implements ActionListener {
    JButton cse,eee,ce,urp,becm,arch,ece,bme,mse,me,iem,le,te,ese,che,mte,back;
    teams(){
        super("teams");
        getContentPane().setBackground(new Color(168,203,255));
//setExtendedState(JFrame.MAXIMIZED_BOTH);

       /* JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);


        JMenu menu = new JMenu("TEAMS");
        menu.setFont(new Font("serif",Font.PLAIN,15));
        menuBar.add(menu);*/

        JLabel lemail = new JLabel(" CRICKET TEAMS");
        lemail.setBounds(50, 30, 850, 30);
        lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,30));
        this.add(lemail);


        cse = new JButton("CSE");
        cse.setBackground(Color.BLUE);
        cse.setForeground(Color.BLACK);
        cse.setBounds(70, 100, 100, 30);
        cse.addActionListener(this);
        add(this.cse);


        eee = new JButton("EEE");
        eee.setBackground(Color.BLUE);
        eee.setForeground(Color.BLACK);
        eee.setBounds(70, 150, 100, 30);
        eee.addActionListener(this);
        add(this.eee);

     /*  ce = new JButton("CE");
       ce.setBackground(Color.BLUE);
      ce.setForeground(Color.BLACK);
       ce.setBounds(70, 160, 100, 20);
    ce.addActionListener(this);
        add(this.ce);

        urp = new JButton("URP");
        urp.setBackground(Color.BLUE);
        urp.setForeground(Color.BLACK);
       urp.setBounds(70, 190, 100, 20);
        urp.addActionListener(this);
        add(this.urp);

     becm = new JButton("BECM");
        becm.setBackground(Color.BLUE);
        becm.setForeground(Color.BLACK);
        becm.setBounds(70, 220, 100, 20);
        becm.addActionListener(this);
        add(this. becm);


     arch = new JButton("ARCH");
        arch.setBackground(Color.BLUE);
        arch.setForeground(Color.BLACK);
        arch.setBounds(70, 250, 100, 20);
        arch.addActionListener(this);
        add(this.   arch);*/


     /*   ece = new JButton("ECE");
        ece.setBackground(Color.BLUE);
        ece.setForeground(Color.BLACK);
        ece.setBounds(70, 280, 100, 20);
        ece.addActionListener(this);
        add(this.ece);*/


       /*bme = new JButton("BME");
        bme.setBackground(Color.BLUE);
        bme.setForeground(Color.BLACK);
        bme.setBounds(70, 310, 100, 20);
        bme.addActionListener(this);
        add(this. bme);


       mse = new JButton("MSE");
        mse.setBackground(Color.BLUE);
        mse.setForeground(Color.BLACK);
        mse.setBounds(70, 340, 100, 20);
        mse.addActionListener(this);
        add(this. mse);*/

        me = new JButton("ME");
        me.setBackground(Color.BLUE);
        me.setForeground(Color.BLACK);
        me.setBounds(70, 200, 100, 30);
        me.addActionListener(this);
        add(this. me);



      /* iem = new JButton("IEM");
        iem .setBackground(Color.BLUE);
        iem .setForeground(Color.BLACK);
        iem .setBounds(70, 440, 100, 20);
        iem .addActionListener(this);
        add(this. iem );

    le = new JButton("LE");
        le.setBackground(Color.BLUE);
        le.setForeground(Color.BLACK);
        le.setBounds(70, 470, 100, 20);
        le.addActionListener(this);
        add(this.  le);



        te = new JButton("TE");
        te.setBackground(Color.BLUE);
        te.setForeground(Color.BLACK);
        te.setBounds(70, 500, 100, 20);
        te.addActionListener(this);
        add(this.  te);


        mte = new JButton("MTE");
      mte.setBackground(Color.BLUE);
        mte.setForeground(Color.BLACK);
        mte.setBounds(70, 530, 100, 20);
        mte.addActionListener(this);
        add(this.  mte);


      ese = new JButton("ESE");
        ese.setBackground(Color.BLUE);
        ese.setForeground(Color.BLACK);
        ese.setBounds(70, 570, 100, 20);
        ese.addActionListener(this);
        add(this.  ese);*/



        back= new JButton("Back");
        back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(70, 300, 100, 30);
        back.addActionListener(this);
        add(this.  back);

        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/team.jpeg"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(100,0,600,450);
        add(profileLable);



        setSize(600, 500);
        setLocation(350, 200);
        setLayout(null);
        setVisible(true);


    }

    public static void main(String[] args) {
        new teams();
    }

    @Override
    public void actionPerformed(ActionEvent E) {
        if(E.getSource()==cse){
            setVisible(false);
            new cse();
        } else if (E.getSource()==eee) {
            setVisible(false);
            new eee();

        } else if (E.getSource()==me) {
            setVisible(false);
            new me();

        }

        else if (E.getSource()==back) {
            setVisible(false);
            new Dashboard();

        }
    }
}
