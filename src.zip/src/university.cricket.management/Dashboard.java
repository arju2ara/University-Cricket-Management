package university.cricket.management;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;



public class Dashboard extends JFrame implements ActionListener{

    JButton player;
    JButton Profile;
    JButton team;

    JButton matches;

    JButton shedules;

    Choice loginchoice;

    Dashboard() {

        super("DASHBOARD ");

        getContentPane().setBackground(Color.getHSBColor(20 ,134,55));
        JLabel lemail = new JLabel(" UNiCricmenia");
        lemail.setBounds(400, 30, 850, 30);
        lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,30));
        this.add(lemail);



        player = new JButton("Exit");
           player.setBackground(Color.BLUE);
        player.setForeground(Color.BLACK);
        player.setBounds(200,380,150,40);//200,100,150,40
        player.addActionListener(this);
        add(this.  player);

       team = new JButton("Teams");
        team.setBackground(Color.BLUE);
        team.setForeground(Color.BLACK);
        team.setBounds(200,100,150,40);//200,170,150,40
        team.addActionListener(this);
        add(this.  team);

        matches = new JButton("Matches");
        matches.setBackground(Color.BLUE);
        matches.setForeground(Color.BLACK);
        matches.setBounds(200,170,150,40);//200,240,150,40
        matches.addActionListener(this);
        add(this.  matches );

        shedules = new JButton("shcedule");
        shedules.setBackground(Color.BLUE);
        shedules.setForeground(Color.BLACK);
        shedules.setBounds(200,240,150,40);//200,310,150,40
        shedules.addActionListener(this);
        add(this. shedules );

       Profile = new JButton("Profile");
        Profile.setBackground(Color.BLUE);
        Profile.setForeground(Color.BLACK);
        Profile.setBounds(200,310,150,40);//200,380,150,40
        Profile.addActionListener(this);
        add(this.  Profile );




        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/dashboard.png"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(300,0,600,500);
        add(profileLable);



        this.setSize(1000, 500);
        this.setLocationRelativeTo(null);
        this.setLocation(250, 100);
        this.setLayout(null);
        this.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==player ){

               // new Players();
                this.dispose();
        } else if (e.getSource()==team) {
            new teams();
            this.dispose();

        }
        else if (e.getSource()==matches) {
                new match();
            this.dispose();

        }
        else if (e.getSource()==shedules) {
            new schedule();
            this.dispose();

        }


        else if (e.getSource()==Profile) {
            new main_class("","");
            this.dispose();

        }


    }


    public static void main(String[] args) {

        new Dashboard();
    }


}
