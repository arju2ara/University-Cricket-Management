package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Players extends JFrame {

Choice      loginAsCho;
    private JFrame frame;
    private JTextArea tableInfoTextArea;
    private JList<String> playerList;
    private List<String> allPlayerNames;
    private DefaultListModel<String> playerListModel;

    JButton addButton,viewDetailsButton,removeButton;

    public Players() {
        frame = new JFrame("Players Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());
        tableInfoTextArea = new JTextArea();


        allPlayerNames = new ArrayList<>();
        playerListModel = new DefaultListModel<>();
        playerList = new JList<>(playerListModel);


        List<String> samplePlayers = new ArrayList<>();
        


        for (String player : samplePlayers) {
            playerListModel.addElement(player);
            allPlayerNames.add(player);
        }


        JScrollPane playerListScrollPane = new JScrollPane(playerList);

        frame.add(playerListScrollPane, BorderLayout.CENTER);




         addButton = new JButton("Add Player");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String playerName = JOptionPane.showInputDialog(frame, "Enter player's name:");
                if (playerName != null && !playerName.isEmpty()) {
                    playerListModel.addElement(playerName);

                    String q="insert into Billsystem.name_info(name) values('"+playerName+"')";



                    try{
                        database c=new database();
                        c.statement.executeUpdate(q);


                    }
                    catch (SQLException ex){
                        ex.printStackTrace();
                    }

                }

               // new information();
            }
        });



        removeButton = new JButton("Remove Player");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                database c = new database();


                String playerNameToRemove = JOptionPane.showInputDialog(frame, "Enter player's name:");;


                String deleteQuery = "DELETE FROM Billsystem.name_info WHERE name = ?";

                try {

                    PreparedStatement preparedStatement = c.connection.prepareStatement(deleteQuery);


                    preparedStatement.setString(1, playerNameToRemove);


                    int rowsAffected = preparedStatement.executeUpdate();


                    if (rowsAffected > 0) {
                        System.out.println("Player '" + playerNameToRemove + "' removed from the database.");
                    } else {
                        System.out.println("Player '" + playerNameToRemove + "' not found in the database.");
                    }

                } catch (SQLException pe) {
                    pe.printStackTrace();
                } finally {

                    try {
                        if (c.connection != null) {
                            c.connection.close();
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }



            }
        });





         viewDetailsButton = new JButton("View Player Details");
        viewDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedPlayer = playerList.getSelectedValue();
                if (selectedPlayer != null) {
                    JOptionPane.showMessageDialog(frame, "Player Details:\nName: " + selectedPlayer);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a player to view details.");
                }
            }
        });


        JButton backButton = new JButton("Back to Dashboard");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new Dashboard();
            }
        });


        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(viewDetailsButton);
        buttonPanel.add(backButton);


        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Players();
        });
    }
}
