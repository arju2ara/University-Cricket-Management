package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.util.Objects;



public class Delete_account extends JFrame implements ActionListener {
    JTextField userText, emailText, PasswordText, IDText;
    Choice delCho;
    JButton delete,back;

    Delete_account() {
        getContentPane().setBackground(Color.GRAY);


        JLabel username = new JLabel("Delete Account");
        username.setBounds(250, 65, 400, 40);
        Font largerFont = new Font(username.getFont().getName(), Font.BOLD, 40);
        username.setFont(largerFont);
        this.add(username);

        JLabel createAs = new JLabel("Delete as");
        createAs.setBounds(180, 150, 150, 30);
        createAs.setFont(new Font(createAs.getFont().getName(), Font.BOLD, 20));
        add(createAs);

        delCho = new Choice();
        delCho.add("Member");
        delCho.add("Admin");
        delCho.setBounds(350, 150, 130, 30);
        add(this.delCho);

        JLabel user = new JLabel("User Name");
        user.setBounds(180, 210, 150, 30);
        user.setFont(new Font(user.getFont().getName(), Font.BOLD, 20));
        this.add(user);

        this.userText = new JTextField();
        this.userText.setBounds(350, 210, 300, 30);
        this.add(this.userText);

        JLabel email = new JLabel("Email");
        email.setBounds(180, 270, 100, 30);
        email.setFont(new Font(email.getFont().getName(), Font.BOLD, 20));
        this.add(email);
this.emailText = new JTextField();
        this.emailText.setBounds(350, 270, 300, 30);
        this.add(this.emailText);

        JLabel Password = new JLabel("Password");
        Password.setBounds(180, 330, 100, 30);
        Password.setFont(new Font(Password.getFont().getName(), Font.BOLD, 20));
        this.add(Password);

        this.PasswordText = new JTextField();
        this.PasswordText.setBounds(350, 330, 300, 30);
        this.add(this.PasswordText);

        JLabel ID = new JLabel("ID");
        ID.setBounds(180, 390, 100, 30);
        ID.setFont(new Font(ID.getFont().getName(), Font.BOLD, 20));
        this.add(ID);
        ID.setVisible(false);

        this.IDText = new JTextField();
        this.IDText.setBounds(350, 390, 300, 30);
        this.add(this.IDText);
        IDText.setVisible(false);

        delete = new JButton("Delete account");
        delete.setBounds(250, 450, 150, 40);
        delete.setFont(new Font(Password.getFont().getName(), Font.BOLD, 15));
        delete.addActionListener(this);
        add(this.delete);

        back = new JButton("Cancle");
        back.setBounds(500, 450, 150, 40);
        back.setFont(new Font(Password.getFont().getName(), Font.BOLD, 15));
        back.addActionListener(this);
        add(this.back);

        delCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String user = delCho.getSelectedItem();
                if (user.equals("Admin")) {
                    ID.setVisible(true);
                    IDText.setVisible(true);

                } else {
                    ID.setVisible(false);
                    IDText.setVisible(false);
                }
            }
        });


        setSize(800, 600);
        setLocation(250, 150);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent E) {
        if (E.getSource()==back){
            setVisible(false);
            new main_class("","");
        }
        else if (E.getSource()==delete){

            String s=new String(delCho.getSelectedItem());
            String n=userText.getText();
            String e=emailText.getText();
            String p=PasswordText.getText();
            String id=IDText.getText();

            if(Objects.equals(s,"Admin")){

                String q = "DELETE FROM Billsystem.admin_info WHERE id = '" + id + "' AND name = '" + n + "' AND email = '" + e + "' AND pass = '" + p + "'";

                try{
                    database c=new database();
                    int f=c.statement.executeUpdate(q);
                    if(f==1) {
                        JOptionPane.showMessageDialog(null, "Account Deleted Successfully.");
                        setVisible(false);
                        new Login();
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"Account can't be delete.");
                        setVisible(false);
                        new Login();
                    }
                }
                catch (SQLException ex){
                    ex.printStackTrace();
                }
            }
            else if(Objects.equals(s,"Member")){

                String q = "DELETE FROM Billsystem.member_info WHERE name = '" + n + "' AND email = '" + e + "' AND pass = '" + p + "'";
                try{
                    database c=new database();
                    int f=c.statement.executeUpdate(q);
                    if(f==1) {
                        JOptionPane.showMessageDialog(null, "Account Deleted Successfully.");
                        setVisible(false);
                        new Login();
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"Account can't be delete.");
                        setVisible(false);
                        new Login();
                    }
                }
                catch (SQLException ex){
                    ex.printStackTrace();
                }
            }
        }
    }
    public static void main(String[] args) {
        new Delete_account();
}
}