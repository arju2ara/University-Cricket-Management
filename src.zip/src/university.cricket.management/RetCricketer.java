
//package university.cricket.management;

//Listview akare show koro
/*
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class RetCricketer {

    public static void main(String[] args) {
        String apiUrl = "https://api.myjson.online/v1/records/a0174034-4d31-46d3-989c-d9c0c8744848";

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();
            connection.disconnect();

            // Parse the JSON array
            JSONObject object = new JSONObject(response.toString());
            JSONArray jsonArray = new JSONArray(object.getJSONArray("data"));

            // Iterate through the array
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                // Access individual values
                System.out.println("Name: " + jsonObject.getString("name"));
                System.out.println("Roll: " + jsonObject.getInt("roll"));
                System.out.println("Batch: " + jsonObject.getString("batch"));
                System.out.println("Department: " + jsonObject.getString("department"));
                System.out.println("Phone Number: " + jsonObject.getString("phone number"));
                System.out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/
package university.cricket.management;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

class Cricketer {
    private String name;
    private int roll;
    private String batch;
    private String department;
    private String phoneNumber;

    public Cricketer(String name, int roll, String batch, String department, String phoneNumber) {
        this.name = name;
        this.roll = roll;
        this.batch = batch;
        this.department = department;
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "Name: " + name +
                ", Roll: " + roll +
                ", Batch: " + batch +
                ", Department: " + department +
                ", Phone Number: " + phoneNumber;
    }
}

class CricketerCellRenderer extends JPanel implements ListCellRenderer<Cricketer> {
    private JLabel label = new JLabel();

    public CricketerCellRenderer() {
        setLayout(new BorderLayout());
        add(label, BorderLayout.CENTER);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends Cricketer> list,
                                                  Cricketer cricketer,
                                                  int index,
                                                  boolean isSelected,
                                                  boolean cellHasFocus) {
        label.setText(cricketer.toString());
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }
}

public class RetCricketer extends JFrame {
    private JList<Cricketer> cricketerList;

    RetCricketer() {
        setTitle("Fancy Cricketer List");

        setSize(1000, 560);
        setLocation(250, 150);
        cricketerList = new JList<>();
        cricketerList.setCellRenderer(new CricketerCellRenderer());
        JScrollPane scrollPane = new JScrollPane(cricketerList);

        // Fetch and set the data to the JList
        fetchCricketerData();

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
    }

    private void fetchCricketerData() {
        String apiUrl = "https://api.myjson.online/v1/records/a0174034-4d31-46d3-989c-d9c0c8744848";

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();
            connection.disconnect();

            // Parse the JSON array
            JSONObject object = new JSONObject(response.toString());
            JSONArray jsonArray = object.getJSONArray("data");

            // Create a list of Cricketer objects
            List<Cricketer> cricketers = new ArrayList<>();

            // Iterate through the array and add data to the list
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                Cricketer cricketer = new Cricketer(
                        jsonObject.getString("name"),
                        jsonObject.getInt("roll"),
                        jsonObject.getString("batch"),
                        jsonObject.getString("department"),
                        jsonObject.getString("phone number")
                );
                cricketers.add(cricketer);
            }

            // Create a DefaultListModel with the list of Cricketers
            DefaultListModel<Cricketer> listModel = new DefaultListModel<>();
            cricketers.forEach(listModel::addElement);

            // Set the list model to the JList
            cricketerList.setModel(listModel);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RetCricketer().setVisible(true));
    }
}
