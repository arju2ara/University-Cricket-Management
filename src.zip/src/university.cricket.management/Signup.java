package university.cricket.management;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.util.Objects;

public class Signup extends JFrame implements ActionListener {

    Choice loginAsCho;
    JTextField enterNa;
    JTextField enterEa;
    JTextField enterPa;
    JTextField enterRePa;
    JTextField enterI;
    JButton CreateButton;
    JButton back;
    Signup(){
        super("SignUp");
        getContentPane().setBackground(new Color(168,203,255));

        JLabel createAs = new JLabel("Create Account as ");
        createAs.setBounds(400, 80, 150, 30);
        createAs.setFont(new Font(createAs.getFont().getName(),Font.BOLD,15));
        add(createAs);

        loginAsCho = new Choice();
        loginAsCho.add("Member");
        loginAsCho.add("Admin");
        loginAsCho.setBounds(600, 80, 130, 30);
        add(this.loginAsCho);

        JLabel enterName = new JLabel("Your Name");
        enterName.setBounds(400, 130, 130, 30);
        enterName.setFont(new Font(enterName.getFont().getName(),Font.BOLD,15));
        enterName.setVisible(true);
        this.add(enterName);

        this.enterNa = new JTextField();
        this.enterNa.setBounds(600, 130, 200, 30);
        this.enterNa.setVisible(true);
        this.add(this.enterNa);

        JLabel enterID = new JLabel("Your ID");
        enterID.setBounds(400, 300, 130, 30);
        enterID.setFont(new Font(enterID.getFont().getName(),Font.BOLD,15));
        enterID.setVisible(false);
        this.add(enterID);

        this.enterI = new JTextField();
        this.enterI.setBounds(600, 300, 200, 30);
        this.enterI.setVisible(false);
        this.add(this.enterI);

        JLabel enterEmail = new JLabel("Enter your Email");
        enterEmail.setBounds(400, 180, 130, 20);
        enterEmail.setFont(new Font(enterEmail.getFont().getName(),Font.BOLD,15));
        this.add(enterEmail);

        this.enterEa = new JTextField();
        this.enterEa.setBounds(600, 180, 200, 20);
        this.add(this.enterEa);

        JLabel enterPassword = new JLabel("Your Password");
        enterPassword.setBounds(400, 230, 130, 30);
        enterPassword.setFont(new Font(enterPassword.getFont().getName(),Font.BOLD,15));
        this.add(enterPassword);

        this.enterPa = new JTextField();
        this.enterPa.setBounds(600, 230, 200, 20);
        this.add(this.enterPa);

        JLabel enterNote = new JLabel("Password must be at least 8 characters!");
        enterNote.setBounds(600, 250, 300, 30);
        this.add(enterNote);

        JLabel enterRePassword = new JLabel("Enter Re-Password");
        enterRePassword.setBounds(400, 300, 150, 30);
        enterRePassword.setVisible(true);
        enterRePassword.setFont(new Font(enterRePassword.getFont().getName(),Font.BOLD,15));
        this.add(enterRePassword);

        this.enterRePa = new JTextField();
        this.enterRePa.setBounds(600, 300, 200, 30);
        enterRePa.setVisible(true);
        this.add(this.enterRePa);

        loginAsCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String user=loginAsCho.getSelectedItem();
                if (user.equals("Admin")){
                    enterID.setVisible(true);
                    enterI.setVisible(true);
                    enterRePassword.setVisible(false);
                    enterRePa.setVisible(false);
                }else{
                    enterID.setVisible(false);
                    enterI.setVisible(false);
                    enterRePassword.setVisible(true);
                    enterRePa.setVisible(true);
                }
            }
        });

        CreateButton = new JButton("Create your Account");
        CreateButton.setBackground(Color.BLUE);
        CreateButton.setForeground(Color.BLACK);
        CreateButton.setBounds(400, 370, 170, 40);
        CreateButton.addActionListener(this);
        add(this.CreateButton);

        back = new JButton("Back");
        back.setBackground(new Color(75, 139, 220, 255));
        back.setForeground(Color.BLACK);
        back.setBounds(600, 370, 100, 40);
        back.addActionListener(this);
        add(this.back);


        ImageIcon boyIcon = new ImageIcon(ClassLoader.getSystemResource("icon/boy.png"));
        Image boyImg = boyIcon.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon boyIcon2 = new ImageIcon(boyImg);
        JLabel boyLabel = new JLabel(boyIcon2);
        boyLabel.setBounds(50,80,250,250);
        add(boyLabel);


        setSize(1000, 560);
        setLocation(250, 150);
        setBackground(Color.BLACK);
        setForeground(Color.WHITE);
        setLayout((LayoutManager) null);
        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent E) {
        if (E.getSource()==CreateButton){

            String s=new String(loginAsCho.getSelectedItem());
            String n=enterNa.getText();
            String e=enterEa.getText();
            String p=enterPa.getText();
            String id=enterI.getText();
            String rep=enterRePa.getText();
            if (Objects.equals(s,"Admin"))
            {

                String q="insert into Billsystem.admin_info(id,name,email,pass) values('"+id+"','"+n+"','"+e+"','"+p+"')";

                try{
                    database c=new database();
                    c.statement.executeUpdate(q);

                    JOptionPane.showMessageDialog(null,"Account Created");
                    setVisible(false);
                   // back.setVisible(false);
                    new Login();
                }
                catch (SQLException ex){
                    ex.printStackTrace();
                }
            }
          else if (Objects.equals(s,"Member")){

                String q="insert into Billsystem.member_info(name,email,pass) values('"+n+"','"+e+"','"+p+"')";

                if(Objects.equals(p,rep)){
                    try{
                        database c=new database();
                        c.statement.executeUpdate(q);

                        JOptionPane.showMessageDialog(null,"Account Created");
                        setVisible(false);
                        new Login();
                    }
                    catch (SQLException ex){
                        ex.printStackTrace();
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null,"Password didn't match");
                }
            }

        } else if (E.getSource()==back) {
            setVisible(false);
            new Login();
        }
    }

    public static void main(String[] args) {

        new Signup();
    }
}