package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class schedule_Update extends JFrame implements ActionListener {
    JTextField enterNa,enterBa,enterRo,enterPo;
    JButton  update,back;

    schedule_Update(){
        getContentPane().setBackground(new Color(168,203,255));
        JLabel enterName = new JLabel(" Team 1");
        enterName.setBounds(400, 130, 130, 30);
        enterName.setFont(new Font(enterName.getFont().getName(), Font.BOLD,15));
        enterName.setVisible(true);
        this.add(enterName);

        this.enterNa = new JTextField();
        this.enterNa.setBounds(600, 130, 200, 30);
        this.enterNa.setVisible(true);
        this.add(this.enterNa);

        JLabel batch = new JLabel("Team 2");
        batch.setBounds(400, 180, 180, 30);
        batch.setFont(new Font(batch.getFont().getName(),Font.BOLD,15));
        batch.setVisible(true);
        this.add(batch);

        this.enterBa = new JTextField();
        this.enterBa.setBounds(600, 180, 200, 30);
        this.enterBa.setVisible(true);
        this.add(this.enterBa);


        JLabel roll = new JLabel("Date");
        roll.setBounds(400, 230, 130, 30);
        roll.setFont(new Font(roll.getFont().getName(),Font.BOLD,15));
        roll.setVisible(true);
        this.add(roll);

        this.enterRo = new JTextField();
        this.enterRo.setBounds(600, 230, 200, 30);
        this.enterRo.setVisible(true);
        this.add(this.enterRo);



        JLabel poaition = new JLabel("Time");
        poaition.setBounds(400, 280, 130, 30);
        poaition.setFont(new Font(poaition.getFont().getName(),Font.BOLD,15));
        poaition.setVisible(true);
        this.add(poaition);

        this.enterPo = new JTextField();
        this.enterPo.setBounds(600, 280, 200, 30);
        this.enterPo.setVisible(true);
        this.add(this.enterPo);


        update = new JButton("Update");
        update.setBackground(Color.BLUE);
        update .setForeground(Color.BLACK);
        update .setBounds(600, 350, 150, 30);
        update.addActionListener(this);
        add(this.  update );



        back = new JButton("Back");
        back .setBackground(Color.BLUE);
        back .setForeground(Color.BLACK);
        back .setBounds(600, 400, 150, 30);
        back .addActionListener(this);
        add(this. back );

        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/hmm.jpg"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(0,0,500,500);
        add(profileLable);

        setSize(1000, 600);
        setLocation(250, 100);
        setLayout(null);
        setVisible(true);


    }
    public static void main(String[] args) {
        new schedule_Update();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==update){
            String name= enterNa.getText();
            String roll= enterRo.getText();
            String batch= enterBa.getText();
            String positon= enterPo.getText();

            String q="insert into Billsystem.schedule_table(team1,team2,date,time) values('"+name+"','"+batch+"','"+roll+"','"+positon+"')";

            try{
                database c=new database();
                c.statement.executeUpdate(q);

                JOptionPane.showMessageDialog(null,"Information added");
                setVisible(false);
                back.setVisible(false);
                // new Login();
                new schedule_admin();
            }
            catch (SQLException ex){
                ex.printStackTrace();
            }
        } else if (e.getSource()== back) {
            setVisible(false);
            new schedule_admin();

        }

    }
}
