package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Objects;

public class match extends JFrame implements ActionListener {
    public Choice loginChoice;
    JTextField userText;
    JButton update,back;

    match(){
        getContentPane().setBackground(new Color(188, 133, 220));
        JLabel login = new JLabel("Enter_As");
        login.setBounds(100, 200, 100, 30);
        login.setFont(new Font(login.getFont().getName(),Font.BOLD,15));
        this.add(login);

        this.loginChoice = new Choice();
        this.loginChoice.add("Admin");
        this.loginChoice.add("Member");
        this.loginChoice.setBounds(200, 200, 100, 40);
        this.add(this.loginChoice);

        JLabel lemail = new JLabel("Email");
        lemail.setBounds(100, 250, 100, 30);
        lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,15));
        this.add(lemail);

        this.userText = new JTextField();
        this.userText.setBounds(200, 250, 250, 30);
        this.add(this.userText);


        update = new JButton("Enter");
        update.setBackground(Color.BLUE);
        update .setForeground(Color.BLACK);
        update .setBounds(100, 350, 150, 30);
        update.addActionListener(this);
        add(this.  update );


        back = new JButton("back");
        back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(300, 350, 150, 30);
        back.addActionListener(this);
        add(this.back);

        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/profile.png"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(300,0,600,500);
        add(profileLable);


        setSize(800, 600);
        setLocation(350, 200);
        setLayout(null);
        setVisible(true);













    }

    public static void main(String[] args) {
        new match();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==update){
            String email=userText.getText();
            String s=loginChoice.getSelectedItem();


            if(Objects.equals(s,"Member")) {

                //  String query = "select * from Billsystem.member_info where email='" + email + "';
                String query = "select * from billsystem.member_info where email='" + email + "'";
                try {
                    database c = new database();
                    ResultSet resultSet = c.statement.executeQuery(query);
                    if (resultSet.next()) {
                        setVisible(false);

                        new match_member();

                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Login");
                    }

                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
            else if(Objects.equals(s,"Admin")){
                String query = "select * from billsystem.admin_info where email='" + email + "'";

                //String query = "select * from Billsystem.admin_info where email='" + email + "';
                try {
                    database c = new database();
                    ResultSet resultSet = c.statement.executeQuery(query);
                    if (resultSet.next()) {
                        setVisible(false);

                        new  match_admin();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Login");
                    }

                } catch (Exception E) {
                    E.printStackTrace();
                }
            }

        } else if (e.getSource()== back) {
            setVisible(false);
            new Dashboard();

        }


    }


}
