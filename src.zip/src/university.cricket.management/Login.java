package university.cricket.management;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Objects;
import javax.swing.*;

public class Login extends JFrame implements ActionListener {
   JTextField userText;
   JTextField PasswordText;
  public Choice loginChoice;
   JButton loginButton;
   JButton cancelButton;
   JButton signUpButton;

   Login() {
      super("Login");
      getContentPane().setBackground(Color.white);
      JLabel lemail = new JLabel("Email");
      lemail.setBounds(300, 60, 100, 20);
      lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,15));
      this.add(lemail);

      this.userText = new JTextField();
      this.userText.setBounds(400, 60, 150, 20);
      this.add(this.userText);

      JLabel Password = new JLabel("Password");
      Password.setBounds(300, 100, 100, 20);
      Password.setFont(new Font(Password.getFont().getName(),Font.BOLD,15));
      this.add(Password);

      this.PasswordText = new JTextField();
      this.PasswordText.setBounds(400,100,150,20);
      this.add(this.PasswordText);

      JLabel login = new JLabel("Login_As");
      login.setBounds(300,140,100,20);
      login.setFont(new Font(login.getFont().getName(),Font.BOLD,15));
      this.add(login);

      this.loginChoice = new Choice();
      this.loginChoice.add("Admin");
      this.loginChoice.add("Member");
      this.loginChoice.setBounds(400,140,150,20);
      this.add(this.loginChoice);

      this.loginButton = new JButton("Login");
      this.loginButton.setBounds(300,180,150,20);
      this.loginButton.addActionListener(this);
      this.add(this.loginButton);

      this.cancelButton = new JButton("Cancel");
      this.cancelButton.setBounds(460,180,100,20);
      this.cancelButton.addActionListener(this);
      this.add(this.cancelButton);

      this.signUpButton = new JButton("SignUp");
      this.signUpButton.setBounds(400,215,100,20);
      this.signUpButton.addActionListener(this);
      this.add(this.signUpButton);

    //  ImageIcon profileIcon = new ImageIcon(ClassLoader.getSystemResource("MovieDe/login.png"));
    // Image profileTow = profileIcon.getImage().getScaledInstance(1000, 575, 1);
    //  ImageIcon fprofileOne = new ImageIcon(profileTow);
  //  JLabel profileLabel = new JLabel(fprofileOne);
   //   this.add(profileLabel);
      ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/profile.png"));
      Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
      ImageIcon fprofileOne = new ImageIcon(profileTow);
      JLabel profileLable = new JLabel(fprofileOne);
      profileLable.setBounds(5,5,250,250);
      add(profileLable);




      this.setSize(640, 300);
      this.setLocationRelativeTo(null);
      this.setLocation(400, 200);
      this.setLayout(null);
      this.setVisible(true);
   }
   //public  String s=loginChoice.getSelectedItem();
   public void actionPerformed(ActionEvent e) {
      if (e.getSource() != loginButton) {
         if (e.getSource() == signUpButton) {
            setVisible(false);
            new Signup();
         } else if (e.getSource() == this.cancelButton) {
            setVisible(false);
         }
      } else if (e.getSource()==loginButton) {
         String email=userText.getText();
         String password=PasswordText.getText();
         String s=loginChoice.getSelectedItem();


         if(Objects.equals(s,"Member")) {

            String query = "select * from Billsystem.member_info where email='" + email + "'and pass='" + password + "'";

            try {
               database c = new database();
               ResultSet resultSet = c.statement.executeQuery(query);
               if (resultSet.next()) {
                  setVisible(false);
                //  new Home();
                  new Dashboard();
               } else {
                  JOptionPane.showMessageDialog(null, "Invalid Login");
               }

            } catch (Exception E) {
               E.printStackTrace();
            }
         }
         else if(Objects.equals(s,"Admin")){
            String query = "select * from Billsystem.admin_info where email='" + email + "'and pass='" + password + "'";
            try {
               database c = new database();
               ResultSet resultSet = c.statement.executeQuery(query);
               if (resultSet.next()) {
                  setVisible(false);
                  new Dashboard();
                 // new Home();
               } else {
                  JOptionPane.showMessageDialog(null, "Invalid Login");
               }

            } catch (Exception E) {
               E.printStackTrace();
            }
         }

      }

   }

   public static void main(String[] args) {
      new Login();
   }
}
