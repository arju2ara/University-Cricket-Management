package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class match_admin extends JFrame implements ActionListener {

    JButton update,show,back,delete;
    match_admin(){
        getContentPane().setBackground(new Color(188, 133, 220));
        JLabel lemail = new JLabel(" Admin Interface");
        lemail.setBounds(100, 30, 300, 30);
        lemail.setFont(new Font(lemail.getFont().getName(),Font.BOLD,30));
        this.add(lemail);



        update = new JButton("Update");
        update.setBackground(Color.BLUE);
        update.setForeground(Color.BLACK);
        update.setBounds(70, 100, 150, 20);
        update.addActionListener(this);
        add(this. update);


        delete = new JButton("Delete");
        delete.setBackground(Color.BLUE);
        delete.setForeground(Color.BLACK);
        delete.setBounds(70, 200, 150, 20);
        delete.addActionListener(this);
        add(this.delete);


        show = new JButton("Show details");
        show.setBackground(Color.BLUE);
        show.setForeground(Color.BLACK);
        show.setBounds(70, 150, 150, 20);
        show.addActionListener(this);
        add(this. show);


        back = new JButton("back");
        back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(70, 250, 150, 20);
        back.addActionListener(this);
        add(this.back);



        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/im.jpeg"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(70,00,600,450);
        add(profileLable);


        setSize(600, 500);
        setLocation(350, 80);
        setLayout(null);
        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==update){
            setVisible(false);

            new match_update();

        } else if (e.getSource()==show) {
            setVisible(false);
            new match_show_details();


        } else if (e.getSource()== back) {
            setVisible(false);
            new Dashboard();}

        else if (e.getSource()== delete) {
            setVisible(false);
            new match_delete();

        }


    }

    public static void main(String[] args) {
        new match_admin();
    }
}
