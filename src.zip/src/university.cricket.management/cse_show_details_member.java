package university.cricket.management;



        import javax.swing.*;
        import java.awt.*;
        import java.awt.event.ActionEvent;
        import java.awt.event.ActionListener;
        import java.sql.*;

public class cse_show_details_member extends JFrame implements ActionListener {

    JButton cse_20,cse_21,cse_22,cse_17,cse_18,cse_19,back;
    private JTextArea tableInfoTextArea;
    JFrame frame;

    cse_show_details_member (){


        getContentPane().setBackground(new Color(175, 224, 184));
        cse_20 = new JButton("CSE 20");
        cse_20.setBackground(Color.BLUE);
        cse_20.setForeground(Color.BLACK);
        cse_20.setBounds(100, 100, 100, 30);
        cse_20.addActionListener(this);
        add(this.cse_20);

        cse_19 = new JButton("CSE 19");
        cse_19.setBackground(Color.BLUE);
        cse_19.setForeground(Color.BLACK);
        cse_19.setBounds(100, 200, 100, 30);
        cse_19.addActionListener(this);
        add(this.cse_19);

        back = new JButton("Back");
        back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(100, 300, 100, 30);
        back.addActionListener(this);
        add(this.back);


        tableInfoTextArea = new JTextArea();
        tableInfoTextArea.setBounds(10, 10, 960, 300); // Set the bounds as per your layout
        JScrollPane scrollPane = new JScrollPane(tableInfoTextArea);
        add(scrollPane);

        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/bill.png"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(200,00,600,430);
        add(profileLable);


        setSize(800, 500);
        setLocation(250, 100);
        setLayout(null);
        setVisible(true);

     /*   cse_21 = new JButton("CSE 21");
        cse_21.setBackground(Color.BLUE);
        cse_21.setForeground(Color.BLACK);
        cse_21.setBounds(530, 350, 100, 20);
        cse_21.addActionListener(this);
        add(this.cse_21);

        cse_22 = new JButton("CSE 22");
        cse_22.setBackground(Color.BLUE);
        cse_22.setForeground(Color.BLACK);
        cse_22.setBounds(630, 350, 100, 20);
        cse_22.addActionListener(this);
        add(this.cse_22);

        cse_17 = new JButton("CSE 19");
        cse_17.setBackground(Color.BLUE);
        cse_17.setForeground(Color.BLACK);
        cse_17.setBounds(400, 400, 100, 20);
        cse_17.addActionListener(this);
        add(this.cse_17);

        cse_18 = new JButton("CSE 18");
        cse_18.setBackground(Color.BLUE);
        cse_18.setForeground(Color.BLACK);
        cse_18.setBounds(530, 400, 100, 20);
        cse_18.addActionListener(this);
        add(this. cse_18);
*/





    }



    public static void main(String[] args) {
        new cse_show_details_member ();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== cse_20){
            setVisible(false);
            SwingUtilities.invokeLater(() -> {
                new member_cse_table_20().setVisible(true);
            });


        }
        else if(e.getSource()== cse_21){
            setVisible(false);
            new  information_21();

        }
        else if(e.getSource()== cse_22){
            setVisible(false);
            new  information_22();

        }

        else if(e.getSource()== cse_19){
            setVisible(false);
            SwingUtilities.invokeLater(() -> {
                new member_information_19().setVisible(true);
            });

        }

        else if(e.getSource()== cse_18){
            setVisible(false);
            SwingUtilities.invokeLater(() -> {
                new information_18().setVisible(true);
            });
        }
        else if(e.getSource()== cse_17){
            setVisible(false);
            new  information_17();

        }
        else if(e.getSource()== back){
            setVisible(false);
            new  cse_member();

        }


    }
}
