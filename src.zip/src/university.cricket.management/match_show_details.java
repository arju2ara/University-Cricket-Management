package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class match_show_details extends JFrame implements ActionListener {

    JButton back,show;
    private JTextArea tableInfoTextArea;
    JFrame frame;

    match_show_details(){

        getContentPane().setBackground(new Color(140, 201, 151));

        show   = new JButton("Show Details");
        show.setBackground(Color.BLUE);
        show.setForeground(Color.BLACK);
        show.setBounds(225, 350, 250, 30);
        show.addActionListener(this);
        add(this.show);

        back = new JButton("Back");
        back.setBackground(Color.BLUE);
        back.setForeground(Color.BLACK);
        back.setBounds(225, 400, 250, 30);
        back.addActionListener(this);
        add(this.back);

        ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/ino.jpeg"));
        Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon fprofileOne = new ImageIcon(profileTow);
        JLabel profileLable = new JLabel(fprofileOne);
        profileLable.setBounds(200,00,300,430);
        add(profileLable);


        setSize(700, 600);
        setLocation(250, 100);
        setLayout(null);
        setVisible(true);
    }


    public static void main(String[] args) {
        new match_show_details();
    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()== show ){
            setVisible(false);
            new match_information();
        } else if (e.getSource()== back) {
            setVisible(false);
            new match_admin();

        }

    }
}
