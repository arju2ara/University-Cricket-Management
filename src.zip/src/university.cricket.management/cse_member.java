package university.cricket.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class cse_member extends JFrame implements ActionListener {
JButton show,back;
    cse_member(){


            getContentPane().setBackground(new Color(161, 130, 130));

            show = new JButton("Show details");
            show.setBackground(Color.BLUE);
            show.setForeground(Color.BLACK);
            show.setBounds(330, 410, 150, 50);
            show.addActionListener(this);
            add(this. show);

            back = new JButton("Back");
            back .setBackground(Color.BLUE);
            back .setForeground(Color.BLACK);
            back .setBounds(330, 470, 150, 50);
            back .addActionListener(this);
            add(this. back );


            ImageIcon profileOne =  new ImageIcon(ClassLoader.getSystemResource("icon/detail.png"));
            Image profileTow = profileOne.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
            ImageIcon fprofileOne = new ImageIcon(profileTow);
            JLabel profileLable = new JLabel(fprofileOne);
            profileLable.setBounds(100,0,600,500);
            add(profileLable);



            setSize(800, 600);
            setLocation(300, 100);
            setLayout(null);
            setVisible(true);




    }

    public static void main(String[] args) {
        new cse_member();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==show){
            setVisible(false);
            new cse_show_details_member();
        } else if (e.getSource()==back) {
            setVisible(false);
            new teams();

        }
    }
}
