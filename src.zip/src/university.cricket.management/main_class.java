package university.cricket.management;



import com.mysql.cj.log.Log;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class main_class extends JFrame implements ActionListener {
    String acctype;
    String meter_pass;
    main_class(String acctype, String meter_pass){

        getContentPane().setBackground(new Color(241, 210, 194));
        this.meter_pass = meter_pass;
        this.acctype = acctype;
        //   setExtendedState(JFrame.MAXIMIZED_BOTH);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/Splash.jpg"));
        Image image = imageIcon.getImage().getScaledInstance(500,300,Image.SCALE_DEFAULT);
        ImageIcon imageIcon2 = new ImageIcon(image);
        JLabel imageLable = new JLabel(imageIcon2);
        imageLable.setBounds(300,150,500,300);
        add(imageLable);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menu = new JMenu("Menu");
        menu.setFont(new Font("serif",Font.PLAIN,15));


        JMenuItem newcustomer = new JMenuItem("New Customer");
        newcustomer.setFont(new Font("monospaced",Font.PLAIN,14));
       // ImageIcon customerImg = new ImageIcon(ClassLoader.getSystemResource("icon/add-group.png"));
      //  Image customerImage = customerImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
      //  newcustomer.setIcon(new ImageIcon(customerImage));
      //  newcustomer.addActionListener(this);
        menu.add(newcustomer);

        JMenuItem customerdetails = new JMenuItem("Customer Details");
        customerdetails.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon customerdetailsImg = new ImageIcon(ClassLoader.getSystemResource("icon/information.png"));
        Image customerdetailsImage = customerdetailsImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        customerdetails.setIcon(new ImageIcon(customerdetailsImage));
        customerdetails.addActionListener(this);
        menu.add(customerdetails);

        JMenuItem depositdetails = new JMenuItem("Deposit Details");
        depositdetails.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon depositdetailsImg = new ImageIcon(ClassLoader.getSystemResource("icon/detail.png"));
        Image depositdetailsImage = depositdetailsImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        depositdetails.setIcon(new ImageIcon(depositdetailsImage));
        depositdetails.addActionListener(this);
        menu.add(depositdetails);

        JMenuItem calculatebill = new JMenuItem("Calculate Bill");
        calculatebill.setFont(new Font("monospaced",Font.PLAIN,14));
        //ImageIcon calculatebillImg = new ImageIcon(ClassLoader.getSystemResource("icon/financial-report.png"));
       // Image calculatebillImage = calculatebillImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
       // calculatebill.setIcon(new ImageIcon(calculatebillImage));
       // calculatebill.addActionListener(this);
        menu.add(calculatebill);


        JMenu info = new JMenu("Profile");
        info.setFont(new Font("serif",Font.PLAIN,15));


        JMenuItem upinfo =new JMenuItem("Update");
        upinfo.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon upinfoImg = new ImageIcon(ClassLoader.getSystemResource("icon/update.png"));
        Image upinfoImage = upinfoImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        upinfo.setIcon(new ImageIcon(upinfoImage));
        upinfo.addActionListener(this);
        info.add(upinfo);

        JMenuItem viewInfo =new JMenuItem("View");
        viewInfo.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon viewInfoImg = new ImageIcon(ClassLoader.getSystemResource("icon/information.png"));
        Image viewInfoImage = viewInfoImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        viewInfo.setIcon(new ImageIcon(viewInfoImage));
        viewInfo.addActionListener(this);
        info.add(viewInfo);



        JMenu utility = new JMenu("RetCricketer");
        utility.setFont(new Font("serif", Font.PLAIN, 15));

        JMenuItem showJsonData = new JMenuItem("Show GSON Data");
        showJsonData.setFont(new Font("monospaced", Font.PLAIN, 14));
        showJsonData.addActionListener(this);
        utility.add(showJsonData);
        menuBar.add(utility);



        JMenu exit = new JMenu("Exit");
        exit.setFont(new Font("serif",Font.PLAIN,15));


        JMenuItem eexit =new JMenuItem("Exit");
        eexit.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon eexitImg = new ImageIcon(ClassLoader.getSystemResource("icon/exit.png"));
        Image eexitImage = eexitImg.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        eexit.setIcon(new ImageIcon(eexitImage));
        eexit.addActionListener(this);
        exit.add(eexit);

        if (acctype.equals("Admin")){
            menuBar.add(menu);
        }else {
          //  menuBar.add(bill);
           // menuBar.add(user);
            menuBar.add(info);
        }
        //  menuBar.add(utility);
        menuBar.add(exit);

        menuBar.setBackground(new Color(241, 196, 196));
        menuBar.setBounds(300,170,1000, 200);

        setSize(900,520);
        setLocation(300,150);
        setLayout(null);
        setVisible(true);


        setLayout(new FlowLayout());
        setVisible(true);
    }

    private void showJsonDataDialog() {
        try {
            URL url = new URL("https://api.myjson.online/v1/records/854acf29-4fd5-49cd-9792-6f69c488609a");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStreamReader reader = new InputStreamReader(connection.getInputStream());

                StringBuilder responseData = new StringBuilder();
                int read;
                char[] buffer = new char[1024];
                while ((read = reader.read(buffer)) != -1) {
                    responseData.append(buffer, 0, read);
                }

                reader.close();

                JSONObject jsonData = new JSONObject(responseData.toString());
                JSONArray players = jsonData.getJSONArray("data");

                JFrame nameFrame = new JFrame("Player Names");
                nameFrame.setSize(400, 300);
                nameFrame.setLayout(new GridLayout(players.length(), 1));

                for (int i = 0; i < players.length(); i++) {
                    JSONObject playerObj = players.getJSONObject(i);
                    String playerName = playerObj.keys().next();
                    JButton nameButton = new JButton(playerName);
                    nameButton.addActionListener(e -> showApplianceInfo(playerName));
                    nameFrame.add(nameButton);
                }

                nameFrame.setVisible(true);

            } else {
                System.out.println("Failed to fetch data. HTTP Response Code: " + connection.getResponseCode());
            }

            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showApplianceInfo(String playerName) {
        try {
            URL url = new URL("https://api.myjson.online/v1/records/854acf29-4fd5-49cd-9792-6f69c488609a");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStreamReader reader = new InputStreamReader(connection.getInputStream());

                StringBuilder responseData = new StringBuilder();
                int read;
                char[] buffer = new char[1024];
                while ((read = reader.read(buffer)) != -1) {
                    responseData.append(buffer, 0, read);
                }

                reader.close();

                JSONObject jsonData = new JSONObject(responseData.toString());
                JSONArray players = jsonData.getJSONArray("data");

                // Find the object with the specified playerName
                JSONObject playerInfo = null;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject playerObj = players.getJSONObject(i);
                    if (playerObj.has(playerName)) {
                        playerInfo = playerObj.getJSONObject(playerName);
                        break;
                    }
                }

                if (playerInfo != null) {
                    String infoText = "Roll: " + playerInfo.getInt("roll") +
                            "\nBatch: " + playerInfo.getString("batch") +
                            "\nDepartment: " + playerInfo.getString("department") +
                            "\nPhone Number: " + playerInfo.getString("phone number");

                    JTextArea textArea = new JTextArea(infoText);
                    textArea.setEditable(false);

                    JScrollPane scrollPane = new JScrollPane(textArea);

                    JFrame playerInfoFrame = new JFrame("Player Information - " + playerName);
                    playerInfoFrame.setSize(400, 300);
                    playerInfoFrame.add(scrollPane);
                    playerInfoFrame.setVisible(true);
                } else {
                    System.out.println("Player not found: " + playerName);
                }
            } else {
                System.out.println("Failed to fetch data. HTTP Response Code: " + connection.getResponseCode());
            }

            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String msg = e.getActionCommand();
        if (msg.equals("Teams")) {
          //  new newCustomer();
            setVisible(false);
            new teams();
        }
        else if (msg.equals("Show GSON Data")) {
            showJsonDataDialog();
        }
        else if (msg.equals("Matches")) {
           // new customer_details();
            setVisible(false);
            new match();
        } else if (msg.equals("schedules")) {
           // new deposit_details();
            setVisible(false);
            new schedule();
        }

        else if (msg.equals("View")) {
            setVisible(false);
            new Details();
        }
        else if (msg.equals("Update")) {
            setVisible(false);
            new Delete_account();
        }
        else if (msg.equals("Bill Details")) {
           // new bill_details(meter_pass);
        }

        else if (msg.equals("Exit")) {
            setVisible(false);
            new Dashboard();

        }

    }

    public static void main(String[] args) {
        new main_class("","");
    }
}