package university.cricket.management;



import javax.swing.*;
        import java.awt.*;
        import java.awt.event.ActionEvent;
        import java.awt.event.ActionListener;
        import java.sql.ResultSet;
        import java.sql.SQLException;


public class Details extends JFrame implements ActionListener {
    JLabel enterEmail,enterName,enterEmail1;
    JTextField userText1, userText2, userText3;
    JButton checkout,back;

    Details() {
        getContentPane().setBackground(new Color(122, 97, 136));

        JLabel username = new JLabel("User Information");
        username.setBounds(300, 80, 500, 40);
        Font largerFont = new Font(username.getFont().getName(), Font.BOLD, 40);
        username.setFont(largerFont);
        this.add(username);

        enterEmail = new JLabel("Email");
        enterEmail.setBounds(300, 200, 100, 30);
        enterEmail.setFont(new Font(enterEmail.getFont().getName(), Font.BOLD, 25));
        enterEmail.setVisible(true);
        this.add(enterEmail);

        this.userText1 = new JTextField();
        this.userText1.setBounds(450, 200, 300, 30);
        this.userText1.setVisible(true);

        this.add(this.userText1);

        enterName = new JLabel("Name");
        enterName.setBounds(300, 200, 100, 30);
        enterName.setFont(new Font(enterName.getFont().getName(), Font.BOLD, 25));
        enterName.setVisible(false);
        this.add(enterName);

        this.userText2 = new JTextField();
        this.userText2.setBounds(450, 200, 300, 30);
        this.userText2.setVisible(false);
        this.add(this.userText2);

        enterEmail1 = new JLabel("Email");
        enterEmail1.setBounds(300, 300, 100, 30);
        enterEmail1.setFont(new Font(enterEmail1.getFont().getName(), Font.BOLD, 25));
        enterEmail1.setVisible(false);
        this.add(enterEmail1);

        this.userText3 = new JTextField();
        this.userText3.setBounds(450, 300, 300, 30);
        this.userText3.setVisible(false);
        this.add(this.userText3);

        checkout = new JButton("Click");
        checkout.setBounds(800, 195, 120, 35);
        checkout.setForeground(Color.BLUE);;
        checkout.setVisible(true);
        checkout.addActionListener(this);
        add(checkout);

        back = new JButton("Back");
        back.setBounds(500, 400, 120, 35);
        back.setFont(new Font(back.getFont().getName(), Font.BOLD, 15));
        back.setVisible(true);
        back.addActionListener(this);
        add(back);

        setSize(1000, 600);
        setLocation(250, 150);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==checkout) {
            String email = userText1.getText();

            boolean flag=false;

            try {
                database c = new database();
                ResultSet resultSet = c.statement.executeQuery("SELECT * FROM Billsystem.admin_info WHERE email='" + userText1.getText() + "'");

                while (resultSet.next()) {
                    String name = resultSet.getString("name");

                    String userEmail = resultSet.getString("email");

                    flag=true;

                    userText2.setText(name);
                    userText3.setText(userEmail);

                    enterEmail.setVisible(false);
                    userText1.setVisible(false);
                    checkout.setVisible(false);
                    enterName.setVisible(true);
                    userText2.setVisible(true);

                    enterEmail1.setVisible(true);
                    userText3.setVisible(true);
                }
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
            if(!flag){
                JOptionPane.showMessageDialog(null,"Invalid Email!");
            }
        } else if (e.getSource()==back) {
            setVisible(false);
            new main_class("","");
        }
    }

    public static void main(String[] args) {
        Details details = new Details();
}
}
